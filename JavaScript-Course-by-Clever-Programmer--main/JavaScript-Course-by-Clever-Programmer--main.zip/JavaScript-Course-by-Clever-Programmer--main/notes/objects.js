// Objects describes something to a computer

// What does this object describe?
let person = {
  name: 'Elon',
  age: 50,
  alive: true,
}

// What would this print?
console.log(person.name)

// How would you print the persons age?
