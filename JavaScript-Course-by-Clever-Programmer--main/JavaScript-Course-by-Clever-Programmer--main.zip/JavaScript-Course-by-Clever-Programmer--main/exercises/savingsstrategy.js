// Test you code by forking this repl: 
// 👉 


// The 50-30-20 strategy is a simple way to budget
// which involves spending 50% of after-tax income on needs,
// 30% after tax income on wants,
// 20% after-tax income on savings or paying off debt.

// Create a function that takes an income amount and return an OBJECT with what they have for needs, wants, and savings

function savingsStrategy (income) {
  
}

// Ex:
// Input: fiftyThirtyTwenty(10000)
// Output: { "Needs": 5000, "Wants": 3000, "Savings": 2000 }


//Topics: Objects