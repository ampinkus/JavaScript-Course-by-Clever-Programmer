// Test you code by forking this repl: 
// 👉 


// Write a function that takes in string and checks if it is a Palindrome
// A palindrome is a word that is the same forwards and backwards!
// Ex: racecar -> racecar

function isPalindrome (string) {
  // Should return true IF it's a palindrome
}


//Topics: Strings, loops