// Test you code by forking this repl: 
// 👉 

// Write a function that takes in an array of numbers and returns the largest number

function findMax (array) {
  
}

//Topics: loops, arrays, conditions,